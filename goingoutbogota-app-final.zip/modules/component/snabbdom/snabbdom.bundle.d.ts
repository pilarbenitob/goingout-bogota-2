export declare const snabbdomBundle: {
    patch: (oldVNode: any, vnode: any) => any;
    h: any;
};
export default snabbdomBundle;
