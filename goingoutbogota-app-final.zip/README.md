# Going-out-Bogot-
The new app that teach you how to dance and be he best at clubs in Bogotá!